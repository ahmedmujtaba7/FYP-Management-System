import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './StudentHome.css';
import axios from 'axios';

const Home = () => {
  const [id, setId] = useState('');
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    // Retrieve ID from internal storage (assuming it's stored as 'userId')
    const storedId = localStorage.getItem('userId');
    setId(storedId);
  }, []);

  useEffect(() => {
    const fetchUsername = async () => {
        if (id) {
          setLoading(true);
          try {
            // Send ID to API endpoint to retrieve username using query parameter
            const response = await axios.get('http://localhost:3001/get-username', {
              params: { id: id } // Send ID as a query parameter
            });
            console.log(response.data.username)
            setUsername(response.data.username);
            setLoading(false);
          } catch (error) {
            setError('Error fetching username');
            setLoading(false);
          }
        }
      };
    fetchUsername();
  }, [id]);

  return (
    <div>
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <div className="student-homepage-container">
      <nav className="navbar">
        <div className="navbar-left">
          <h1 className="navbar-title">FYP Manager</h1>
        </div>
        <div className="navbar-right">
          <ul className="navbar-list">
            <li>
              <Link to="/S-Home">Home</Link>
            </li>
            <li>
              <Link to="/S-ViewProjectTitle">Project Title</Link>
            </li>
            <li>
              <Link to="/S-ViewSupervisor">Supervisor</Link>
            </li>
            <li>
              <Link to="/S-ViewDeadline">Deadlines</Link>
            </li>
            <li>
              {/* Update the link to navigate to "/S-GradesReport" */}
              <Link to="/S-ViewGroup">Group</Link>
            </li>
            <li>
              <Link to="/S-ViewPanel">Panel</Link>
            </li>
          </ul>
        </div>
      </nav>
      <div className="welcome-container">
        <h1 className="welcome-text">Welcome, {username}</h1>
      </div>
      </div>
      )}
    </div>
  );
};

export default Home;
