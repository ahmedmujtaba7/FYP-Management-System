import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './StudentHome.css'

const CProjectDetails = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        // Fetch projects from the API
        const response = await axios.get('http://localhost:3001/projects');
        setProjects(response.data.projects);
        setLoading(false);
      } catch (error) {
        setError('Error fetching projects');
        setLoading(false);
      }
    };

    fetchProjects();
  }, []);

  return (
    <div className="student-homepage-container">
      <nav className="navbar">
        <div className="navbar-left">
          <h1 className="navbar-title">FYP Manager</h1>
        </div>
        <div className="navbar-right">
          <ul className="navbar-list">
          <li>
              <Link to="/C-ProjectDetails">Project Details</Link>
            </li>
            <li>
              <Link to="/C-RegisterProject">Register Project</Link>
            </li>
            <li>
              <Link to="/C-RegisterStudent">Register Student</Link>
            </li>
            <li>
              <Link to="/C-AssignDeadline">Deadlines</Link>
            </li>
            <li>
              <Link to="/C-AssignPanel">Assign Panel</Link>
            </li>
            <li>
              <Link to="/C-AssignRole">Assign Role</Link>
            </li>
            <li>
              <Link to="/C-AssignSupervisor">Assign Supervisor</Link>
            </li>
            <li>
              <Link to="/C-AssignGroup">Assign Group</Link>
            </li>
            <li>
              <Link to="/C-AssignProject">Assign Project</Link>
            </li>
          </ul>
        </div>
      </nav>
    <div>
      <h2>Project List</h2>
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Title</th>
              <th>Description</th>
              <th>Students</th>
              <th>Supervisor</th>
            </tr>
          </thead>
          <tbody>
            {projects.map((project, index) => (
              <tr key={index}>
                <td>{project.title}</td>
                <td>{project.description}</td>
                <td>
                  <ul>
                    {project.students.map((student, index) => (
                      <li key={index}>{student.name} ({student.email})</li>
                    ))}
                  </ul>
                </td>
                <td>{project.supervisor.name} ({project.supervisor.email})</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
    </div>
  );
};

export default CProjectDetails;
