import React, { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './StudentHome.css'

const RegisterStudent = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate name length
    if (name.length > 15) {
      setError('Name should not be longer than 15 characters');
      return;
    }

    if (name.length < 5) {
      setError('Name should not be shorter than 5 characters');
      return;
    }

    // Validate password contains capital and special characters
    const regex = /^(?=.*[A-Z])(?=.*[!@#$%^&*])/
    if (!regex.test(password)) {
      setError('Password should contain at least one capital letter and one special character');
      return;
    }
    if (password.length<8 || password.length>15) {
      setError('Password should contain at least 8 characters and  at most 15 characters');
      return;
    }

    try {
      // Send registration data to the backend API
      const response = await axios.post('http://localhost:3001/register', {
        name,
        email,
        password
      });

      // Display success message
      if (response.data.success) {
        alert('Registration successful!');
        // Clear form fields
        setName('');
        setEmail('');
        setPassword('');
        setError('');
      }
    } catch (error) {
      // Display error message if registration fails
      setError('Failed to register. Please try again.');
    }
  };

  return (
    <div className="student-homepage-container">
      <nav className="navbar">
        <div className="navbar-left">
          <h1 className="navbar-title">FYP Manager</h1>
        </div>
        <div className="navbar-right">
          <ul className="navbar-list">
          <li>
              <Link to="/C-ProjectDetails">Project Details</Link>
            </li>
            <li>
              <Link to="/C-RegisterProject">Register Project</Link>
            </li>
            <li>
              <Link to="/C-RegisterStudent">Register Student</Link>
            </li>
            <li>
              <Link to="/C-AssignDeadline">Deadlines</Link>
            </li>
            <li>
              <Link to="/C-AssignPanel">Assign Panel</Link>
            </li>
            <li>
              <Link to="/C-AssignRole">Assign Role</Link>
            </li>
            <li>
              <Link to="/C-AssignSupervisor">Assign Supervisor</Link>
            </li>
            <li>
              <Link to="/C-AssignGroup">Assign Group</Link>
            </li>
            <li>
              <Link to="/C-AssignProject">Assign Project</Link>
            </li>
          </ul>
        </div>
      </nav>
      <div className="form-container">
  <h2>Registration Form</h2>
  <form onSubmit={handleSubmit}>
    <div>
      <label htmlFor="name">Name:</label>
      <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} required />
    </div>
    <div>
      <label htmlFor="email">Email:</label>
      <input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
    </div>
    <div>
      <label htmlFor="password">Password:</label>
      <input type="password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
    </div>
    {error && <p>{error}</p>}
    <button type="submit">Register</button>
  </form>
</div>

    </div>
  );
};

export default RegisterStudent;
