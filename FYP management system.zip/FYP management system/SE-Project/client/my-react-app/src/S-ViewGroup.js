import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const ViewGroup = () => {
  const [groupMembers, setGroupMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchGroupMembers = async () => {
      try {
        // Retrieve student ID from local storage
        const id = localStorage.getItem('userId');
        
        // Send request to backend API to get group members
        const response = await axios.get('http://localhost:3001/group-members', {
          params: { id: id }
        });
        
        // Set the group members state with the response data
        setGroupMembers(response.data.groupMembers);
        setLoading(false);
      } catch (error) {
        // Handle any errors
        setError('Error fetching group members');
        setLoading(false);
      }
    };

    // Call the fetchGroupMembers function when the component mounts
    fetchGroupMembers();
  }, []);

  return (
    <div>
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <div className="student-homepage-container">
      <nav className="navbar">
        <div className="navbar-left">
          <h1 className="navbar-title">FYP Manager</h1>
        </div>
        <div className="navbar-right">
          <ul className="navbar-list">
          <li>
              <Link to="/S-Home">Home</Link>
            </li>
            <li>
              <Link to="/S-ViewProjectTitle">Project Title</Link>
            </li>
            <li>
              <Link to="/S-ViewSupervisor">Supervisor</Link>
            </li>
            <li>
              <Link to="/S-ViewDeadline">Deadlines</Link>
            </li>
            <li>
              {/* Update the link to navigate to "/S-GradesReport" */}
              <Link to="/S-ViewGroup">Group</Link>
            </li>
            <li>
              <Link to="/S-ViewPanel">Panel</Link>
            </li>
          </ul>
        </div>
      </nav>
        <div className="welcome-container">
          <p>Group members:</p>
          <ul>
            {groupMembers.map((member, index) => (
              <li key={index}>
                <strong>Name:</strong> {member.name}, <strong>Email:</strong> {member.email}
              </li>
            ))}
          </ul>
        </div>
        </div>
      )}
    </div>
  );
};

export default ViewGroup;
