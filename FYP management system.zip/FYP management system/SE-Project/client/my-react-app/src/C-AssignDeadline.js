import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import './StudentHome.css'
const AssignDeadline = () => {
  const [projectsWithoutDeadline, setProjectsWithoutDeadline] = useState([]);
  const [selectedDate, setSelectedDate] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    // Fetch projects without deadline
    const fetchProjectsWithoutDeadline = async () => {
      try {
        const response = await axios.get('http://localhost:3001/projects-without-deadline');
        setProjectsWithoutDeadline(response.data.projectsWithoutDeadline);
      } catch (error) {
        console.error('Error fetching projects without deadline:', error);
      }
    };

    fetchProjectsWithoutDeadline();
  }, []);

  const handleAssignDeadline = async () => {
    try {
      const projectIds = projectsWithoutDeadline.map(project => project._id);
      const response = await axios.post('http://localhost:3001/assign-deadline-to-projects', {
        deadlineDate: selectedDate,
        projectIds: projectIds
      });
      setMessage(response.data.message);
      // Display success message in an alert
      alert(response.data.message);
    } catch (error) {
      // Display error message in an alert
      alert('Error assigning deadline to projects');
    }
  };

  return (
    <div className="student-homepage-container">
      <nav className="navbar">
        <div className="navbar-left">
          <h1 className="navbar-title">FYP Manager</h1>
        </div>
        <div className="navbar-right">
          <ul className="navbar-list">
          <li>
              <Link to="/C-ProjectDetails">Project Details</Link>
            </li>
            <li>
              <Link to="/C-RegisterProject">Register Project</Link>
            </li>
            <li>
              <Link to="/C-RegisterStudent">Register Student</Link>
            </li>
            <li>
              <Link to="/C-AssignDeadline">Deadlines</Link>
            </li>
            <li>
              <Link to="/C-AssignPanel">Assign Panel</Link>
            </li>
            <li>
              <Link to="/C-AssignRole">Assign Role</Link>
            </li>
            <li>
              <Link to="/C-AssignSupervisor">Assign Supervisor</Link>
            </li>
            <li>
              <Link to="/C-AssignGroup">Assign Group</Link>
            </li>
            <li>
              <Link to="/C-AssignProject">Assign Project</Link>
            </li>
          </ul>
        </div>
      </nav>
    <div>
      <h2>Assign Deadline to Projects</h2>
      <div>
        <h3>Projects Without Deadline:</h3>
        <ul>
          {projectsWithoutDeadline.map(project => (
            <li key={project._id}>{project.title}</li>
          ))}
        </ul>
      </div>
      <div>
        <label>Select Deadline Date:</label>
        <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} />
      </div>
      <button onClick={handleAssignDeadline}>Assign Deadline</button>
    </div>
    </div>
  );
};

export default AssignDeadline;
