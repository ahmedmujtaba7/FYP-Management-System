import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import Login from './Login';
import CProjectDetails from './C-ProjectDetails';
import Home from './S-Home';
import ViewSupervisor from './S-ViewSupervisor';
import ViewProject from './S-ViewProjectTitle';
import ViewGroup from './S-ViewGroup';
import RegisterStudent from './C-RegisterStudent';
import RegisterProject from './C-RegisterProject';
import AssignGroups from './C-AssignGroup';
import AssignRoles from './C-AssignRole';
import AssignSupervisor from './C-AssignSup';
import AssignPanel from './C-AssignPanel';
import AssignProject from './C-AssignProject';
import AssignDeadline from './C-AssignDeadline';
import ViewDeadline from './S-ViewDeadline';
import ViewPanel from './S-ViewPanel';
import SProjectDetails from './Sup-ViewProject';
import PprojectDetails from './P-ViewProjects';
import AssignGrade from './Sup-AssignGrade';

function App() {
  const [userRole, setUserRole] = useState(null);
  console.log(userRole)
  return (
    <Router>
      <Switch>
        <Route exact path="/"> 
        <Login setUserRole={setUserRole} /> 
        </Route>
        {userRole === 'committeeMember' && (
          // Redirect committee members to C-ProjectDetails after successful login
          <Redirect from="/" to="/C-RegisterStudent" />
        )
        }
        {/* {userRole === 'panel' && (
          // Redirect committee members to C-ProjectDetails after successful login
          <Redirect from="/" to="/P-ViewProjects" />
        )
        } */}
        {/* {userRole === 'supervisor' && (
          // Redirect committee members to C-ProjectDetails after successful login
          <Redirect from="/" to="/Sup-ViewProject" />
        )
        } */}
        {/* {userRole === 'student' && (
          // Redirect committee members to C-ProjectDetails after successful login
          <Redirect from="/" to="/S-Home" />
        )
        } */}
        <Route path="/C-RegisterStudent" component={RegisterStudent} />
        <Route path="/C-ProjectDetails" component={CProjectDetails} />
        <Route path="/S-Home" component={Home} />
        <Route path="/S-ViewPanel" component={ViewPanel} />
        <Route path="/S-ViewProjectTitle" component={ViewProject} />
        <Route path="/S-ViewSupervisor" component={ViewSupervisor} />
        <Route path="/S-ViewDeadline" component={ViewDeadline} />
        <Route path="/S-ViewGroup" component={ViewGroup} />
        <Route path="/C-AssignPanel" component={AssignPanel} />
        <Route path="/C-AssignProject" component={AssignProject} />
        <Route path="/P-ViewProjects" component={PprojectDetails} />
        <Route path="/Sup-ViewProject" component={SProjectDetails} />
        <Route path="/assign-supervisor" component={AssignSupervisor} />
        <Route path="/C-AssignRole" component={AssignRoles} />
        <Route path="/C-AssignDeadline" component={AssignDeadline} />
        <Route path="/C-AssignPanel" component={AssignPanel} />
        <Route path="/C-AssignSupervisor" component={AssignSupervisor} />
        <Route path="/C-AssignGroup" component={AssignGroups} />
        <Route path="/C-RegisterProject" component={RegisterProject} />
        <Route path="/assign-grade" component={AssignGrade} />
        {/* Define other routes for different pages if needed */}
      </Switch>
    </Router>
  );
}

export default App;
