import React, { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './StudentHome.css'

const RegisterProject = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess(false);
    setLoading(true);

    try {
      // Validate project title and description lengths
      if (title.length > 15 || description.length > 150) {
        setError('Project title must be less than 15 characters and description must be less than 150 characters.');
        setLoading(false);
        return;
      }
      if (title.length < 5 || description.length < 15) {
        setError('Project title must be greater than 5 characters and description must be greater than 15 characters.');
        setLoading(false);
        return;
      }

      // Send project data to the backend API
      const response = await axios.post('http://localhost:3001/add-project', { title, description });

      if (response.data.success) {
        alert('Project Added successfully!');
        setSuccess(true);
        setTitle('');
        setDescription('');
      } else {
        setError('Failed to add project. Please try again.');
      }
    } catch (error) {
      setError('Error adding project. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="student-homepage-container">
      <nav className="navbar">
        <div className="navbar-left">
          <h1 className="navbar-title">FYP Manager</h1>
        </div>
        <div className="navbar-right">
          <ul className="navbar-list">
          <li>
              <Link to="/C-ProjectDetails">Project Details</Link>
            </li>
            <li>
              <Link to="/C-RegisterProject">Register Project</Link>
            </li>
            <li>
              <Link to="/C-RegisterStudent">Register Student</Link>
            </li>
            <li>
              <Link to="/C-AssignDeadline">Deadlines</Link>
            </li>
            <li>
              <Link to="/C-AssignPanel">Assign Panel</Link>
            </li>
            <li>
              <Link to="/C-AssignRole">Assign Role</Link>
            </li>
            <li>
              <Link to="/C-AssignSupervisor">Assign Supervisor</Link>
            </li>
            <li>
              <Link to="/C-AssignGroup">Assign Group</Link>
            </li>
            <li>
              <Link to="/C-AssignProject">Assign Project</Link>
            </li>
          </ul>
        </div>
      </nav>
      <div className="form-container">
  <h2>Add Project</h2>
  <form onSubmit={handleSubmit}>
    <div>
      <label htmlFor="title">Project Title:</label>
      <input type="text" id="title" value={title} onChange={(e) => setTitle(e.target.value)} />
    </div>
    <div>
      <label htmlFor="description">Project Description:</label>
      <textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} />
    </div>
    <button type="submit" disabled={loading}>Register</button>
  </form>
  {loading && <p>Loading...</p>}
  {error && <p className="error-message">{error}</p>}
  {success && <p className="success-message">Project added successfully!</p>}
</div>

    </div>
  );
};

export default RegisterProject;
