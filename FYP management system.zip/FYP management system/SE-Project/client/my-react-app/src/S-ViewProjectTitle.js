import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const ViewProject = () => {
  const [id, setId] = useState('');
  const [projectTitle, setProjectTitle] = useState('');
  const [projectDescription, setProjectDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    // Retrieve ID from internal storage (assuming it's stored as 'userId')
    const storedId = localStorage.getItem('userId');
    setId(storedId);
  }, []);

  useEffect(() => {
    const fetchProjectDetails = async () => {
      if (id) {
        setLoading(true);
        try {
          // Send ID to API endpoint to retrieve project details using query parameter
          const response = await axios.get('http://localhost:3001/get-project-details', {
            params: { id: id } // Send ID as a query parameter
          });
          setProjectTitle(response.data.projectTitle);
          setProjectDescription(response.data.projectDescription);
          setLoading(false);
        } catch (error) {
          setError('Error fetching project details');
          setLoading(false);
        }
      }
    };
    fetchProjectDetails();
  }, [id]);

  return (
    <div>
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <div className="student-homepage-container">
          <nav className="navbar">
            <div className="navbar-left">
              <h1 className="navbar-title">FYP Manager</h1>
            </div>
            <div className="navbar-right">
              <ul className="navbar-list">
              <li>
              <Link to="/S-Home">Home</Link>
            </li>
            <li>
              <Link to="/S-ViewProjectTitle">Project Title</Link>
            </li>
            <li>
              <Link to="/S-ViewSupervisor">Supervisor</Link>
            </li>
            <li>
              <Link to="/S-ViewDeadline">Deadlines</Link>
            </li>
            <li>
              {/* Update the link to navigate to "/S-GradesReport" */}
              <Link to="/S-ViewGroup">Group</Link>
            </li>
            <li>
              <Link to="/S-ViewPanel">Panel</Link>
            </li>
              </ul>
            </div>
          </nav>
          <div className="welcome-container">
            <h1 className="welcome-text">Project Details</h1>
            <h2>Title: {projectTitle}</h2>
            <p>Description: {projectDescription}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default ViewProject;
