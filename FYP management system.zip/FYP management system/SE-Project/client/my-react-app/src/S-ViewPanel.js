import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const PanelMembers = () => {
  const [panelMembers, setPanelMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchPanelMembers = async () => {
      try {
        // Retrieve student ID from local storage
        const studentId = localStorage.getItem('userId');

        // Send request to backend API to get panel members
        const response = await axios.get('http://localhost:3001/panel-members', {
          params: { id: studentId }
        });

        // Set the panel members state with the response data
        setPanelMembers(response.data.panelMembers);
        setLoading(false);
      } catch (error) {
        // Handle any errors
        setError('Error fetching panel members');
        setLoading(false);
      }
    };

    // Call the fetchPanelMembers function when the component mounts
    fetchPanelMembers();
  }, []);

  return (
    <div>
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <div className="student-homepage-container">
      <nav className="navbar">
        <div className="navbar-left">
          <h1 className="navbar-title">FYP Manager</h1>
        </div>
        <div className="navbar-right">
          <ul className="navbar-list">
          <li>
              <Link to="/S-Home">Home</Link>
            </li>
            <li>
              <Link to="/S-ViewProjectTitle">Project Title</Link>
            </li>
            <li>
              <Link to="/S-ViewSupervisor">Supervisor</Link>
            </li>
            <li>
              <Link to="/S-ViewDeadline">Deadlines</Link>
            </li>
            <li>
              {/* Update the link to navigate to "/S-GradesReport" */}
              <Link to="/S-ViewGroup">Group</Link>
            </li>
            <li>
              <Link to="/S-ViewPanel">Panel</Link>
            </li>
          </ul>
        </div>
      </nav>
      <div>
          <h2>Panel Members</h2>
          <ol>
            {panelMembers.map((member, index) => (
              <li key={index}>{member.name}</li>
            ))}
          </ol>
        </div>
        </div>
      )}
    </div>
  );
};

export default PanelMembers;
