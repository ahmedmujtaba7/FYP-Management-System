import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './StudentHome.css'

const AssignSupervisor = () => {
  // State variables
  const [projectsWithoutSupervisor, setProjectsWithoutSupervisor] = useState([]);
  const [supervisorsWithLimitedFYPs, setSupervisorsWithLimitedFYPs] = useState([]);
  const [selectedProject, setSelectedProject] = useState('');
  const [selectedSupervisor, setSelectedSupervisor] = useState('');

  // Fetch projects without supervisors and supervisors with limited FYPs
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch projects without supervisors
        const projectsRes = await axios.get('http://localhost:3001/projects-without-supervisor');
        setProjectsWithoutSupervisor(projectsRes.data.projectsWithoutSupervisor);

        // Fetch supervisors with limited FYPs
        const supervisorsRes = await axios.get('http://localhost:3001/supervisors-with-limited-fyps');
        setSupervisorsWithLimitedFYPs(supervisorsRes.data.facultyMembers);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  // Event handler for assigning supervisor to project
  const handleAssignSupervisor = async () => {
    try {
      // Send request to assign supervisor to project
      const response = await axios.post('http://localhost:3001/assign-supervisor-to-project', {
        supervisorId: selectedSupervisor,
        projectId: selectedProject
      });

      // Display response message in an alert
      alert(response.data.message);
      if(response.success){
        const projectsRes2 = await axios.get('http://localhost:3001/incrementincrement-maxFYPs',{
          supervisorId: selectedSupervisor,
        });
        console.log(projectsRes2.data.message);
      }
    } catch (error) {
      console.error('Error assigning supervisor to project:', error);
    }
  };

  return (
    <div className="student-homepage-container">
      <nav className="navbar">
        <div className="navbar-left">
          <h1 className="navbar-title">FYP Manager</h1>
        </div>
        <div className="navbar-right">
          <ul className="navbar-list">
          <li>
              <Link to="/C-ProjectDetails">Project Details</Link>
            </li>
            <li>
              <Link to="/C-RegisterProject">Register Project</Link>
            </li>
            <li>
              <Link to="/C-RegisterStudent">Register Student</Link>
            </li>
            <li>
              <Link to="/C-AssignDeadline">Deadlines</Link>
            </li>
            <li>
              <Link to="/C-AssignPanel">Assign Panel</Link>
            </li>
            <li>
              <Link to="/C-AssignRole">Assign Role</Link>
            </li>
            <li>
              <Link to="/C-AssignSupervisor">Assign Supervisor</Link>
            </li>
            <li>
              <Link to="/C-AssignGroup">Assign Group</Link>
            </li>
            <li>
              <Link to="/C-AssignProject">Assign Project</Link>
            </li>
          </ul>
        </div>
      </nav>
    <div>
      <h2>Assign Supervisor to Project</h2>
      <div>
  <h3>Select Project:</h3>
  <select
  value={selectedProject}
  onChange={(e) => setSelectedProject(e.target.value)}
 // Inline CSS to set width and height
>
  <option value="">Select Project</option>
  {projectsWithoutSupervisor.map(project => (
    <option key={project._id} value={project._id}>{project.title}</option>
  ))}
</select>
</div>

      <div>
        <h3>Select Supervisor:</h3>
        <select value={selectedSupervisor} onChange={(e) => setSelectedSupervisor(e.target.value)}>
          <option value="">Select Supervisor</option>
          {supervisorsWithLimitedFYPs.map(supervisor => (
            <option key={supervisor.supervisorId} value={supervisor.supervisorId}>{supervisor.name}</option>
          ))}
        </select>
      </div>
      <button onClick={handleAssignSupervisor}>Assign Supervisor</button>
    </div>
    </div>
  );
};

export default AssignSupervisor;
