import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './StudentHome.css'

const AssignRoles = () => {
  const [unassignedFaculty, setUnassignedFaculty] = useState([]);
  const [selectedRoles, setSelectedRoles] = useState({});

  useEffect(() => {
    const fetchUnassignedFaculty = async () => {
      try {
        const response = await axios.get('http://localhost:3001/unassigned-faculty');
        setUnassignedFaculty(response.data.unassignedFaculty);
      } catch (error) {
        console.error('Error fetching unassigned faculty:', error);
      }
    };
    fetchUnassignedFaculty();
  }, []);

  const handleCheckboxChange = (id, role) => {
    setSelectedRoles({ ...selectedRoles, [id]: role });
  };

  const handleAssignRole = async () => {
    try {
      const assignments = [];
      for (const id in selectedRoles) {
        assignments.push({ id, role: selectedRoles[id] });
      }
      const response = await axios.post('http://localhost:3001/assign-role', assignments);
      alert(response.data.message);
    } catch (error) {
      console.error('Error assigning roles:', error);
      alert('Error assigning roles. Please try again.');
    }
  };

  return (
    <div className="student-homepage-container">
      <nav className="navbar">
        <div className="navbar-left">
          <h1 className="navbar-title">FYP Manager</h1>
        </div>
        <div className="navbar-right">
          <ul className="navbar-list">
          <li>
              <Link to="/C-ProjectDetails">Project Details</Link>
            </li>
            <li>
              <Link to="/C-RegisterProject">Register Project</Link>
            </li>
            <li>
              <Link to="/C-RegisterStudent">Register Student</Link>
            </li>
            <li>
              <Link to="/C-AssignDeadline">Deadlines</Link>
            </li>
            <li>
              <Link to="/C-AssignPanel">Assign Panel</Link>
            </li>
            <li>
              <Link to="/C-AssignRole">Assign Role</Link>
            </li>
            <li>
              <Link to="/C-AssignSupervisor">Assign Supervisor</Link>
            </li>
            <li>
              <Link to="/C-AssignGroup">Assign Group</Link>
            </li>
            <li>
              <Link to="/C-AssignProject">Assign Project</Link>
            </li>
          </ul>
        </div>
      </nav>
    <div>
      <h2>Assign Roles to Faculty Members</h2>
      {unassignedFaculty.map((faculty) => (
        <div key={faculty._id}>
          <h3>{faculty.name}</h3>
          <label>
            Panel
            <input
              type="checkbox"
              checked={selectedRoles[faculty._id] === 'Panel'}
              onChange={() => handleCheckboxChange(faculty._id, 'Panel')}
            />
          </label>
          <label>
            Supervisor
            <input
              type="checkbox"
              checked={selectedRoles[faculty._id] === 'Supervisor'}
              onChange={() => handleCheckboxChange(faculty._id, 'Supervisor')}
            />
          </label>
        </div>
      ))}
      <button onClick={handleAssignRole}>Assign Roles</button>
    </div>
    </div>
  );
};

export default AssignRoles;
