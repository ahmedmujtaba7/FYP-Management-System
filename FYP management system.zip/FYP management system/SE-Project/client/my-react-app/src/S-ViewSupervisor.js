import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const ViewSupervisor = () => {
  const [supervisorName, setSupervisorName] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    // Fetch student ID from local storage
    const studentId = localStorage.getItem('userId');

    // Make API call to get supervisor name
    axios.get('http://localhost:3001/get-supervisor-name',{
        params: { id: studentId }
    })
      .then(response => {
        setSupervisorName(response.data.supervisorName);
        setLoading(false);
      })
      .catch(error => {
        setError('Error retrieving supervisor name');
        setLoading(false);
      });
  }, []);

  return (
    <div>
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <div className="student-homepage-container">
      <nav className="navbar">
        <div className="navbar-left">
          <h1 className="navbar-title">FYP Manager</h1>
        </div>
        <div className="navbar-right">
          <ul className="navbar-list">
          <li>
              <Link to="/S-Home">Home</Link>
            </li>
            <li>
              <Link to="/S-ViewProjectTitle">Project Title</Link>
            </li>
            <li>
              <Link to="/S-ViewSupervisor">Supervisor</Link>
            </li>
            <li>
              <Link to="/S-ViewDeadline">Deadlines</Link>
            </li>
            <li>
              {/* Update the link to navigate to "/S-GradesReport" */}
              <Link to="/S-ViewGroup">Group</Link>
            </li>
            <li>
              <Link to="/S-ViewPanel">Panel</Link>
            </li>
          </ul>
        </div>
      </nav>
      <div className="welcome-container">
        <h1 className="welcome-text">Supervisor Name</h1>
        <h2>{supervisorName}</h2>
      </div>
      </div>
      )}
    </div>
  );
};
export default ViewSupervisor;